import StreamChat
import StreamChatSwiftUI
import UIKit
import SwiftUI

class AppDelegate: NSObject, UIApplicationDelegate {
    
    let myGradient = LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing)
    
    var streamChat: StreamChat?
    
    var chatClient: ChatClient = {
        var config = ChatClientConfig(apiKey: .init("8br4watad788"))
        config.applicationGroupIdentifier = "group.io.getstream.iOS.ChatDemoAppSwiftUI"
        
        let client = ChatClient(config: config)
        return client
    }()
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions:
                     [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        // Color supplier: Provides the colors used throughout the SDK.
        // 1. Create instance of the color palette object
        var colors = ColorPalette()
        // Define the system-wide accent color
        let nordeaAccentColor = Color(#colorLiteral(red: 0.05098039216, green: 0.5098039216, blue: 0.4078431373, alpha: 1)) // Text of: Navigation links, chat bubbles, instant commands, context menu, menu icon (swipe to reveal), links in messages, read receipt
        let cloudBlue = Color(#colorLiteral(red: 0.862745098, green: 0.9294117647, blue: 1, alpha: 1)) // Outgouing chat bubble
        let darkPink = Color(#colorLiteral(red: 0.9411764706, green: 0.7568627451, blue: 0.6823529412, alpha: 1)) // Incoming chat bubble
        
        // Change the color of navigation icon, scroll-to button and read indicator
        colors.tintColor = nordeaAccentColor
        
        
        // Channel list name, chat bubble text, context menu text
        colors.text = UIColor(nordeaAccentColor)
        
        // Message bubble content fontSize, context menu
        //fonts.body = .system(size: 45).italic()
        
        // Backgrounds of: Channel list, chat area, instant commands, and compose area
        colors.background = UIColor(cloudBlue)
        
        // Background of: Searchbar
        colors.background1 = UIColor(Color(.systemGray4))
        
        // Background of: Outgoing message bubbles
        colors.background6 = UIColor(cloudBlue)
        
        // Backgrounds of: Incoming message bubbles, context menu, reactions
        colors.background8 = UIColor(darkPink)
        
        // Color for giphy label
        colors.staticColorText = .systemBlue
        
        colors.highlightedBackground = .blue
        
        // 2. Create instance of the font object
        var fonts = Fonts()
        fonts.body =  .largeTitle
       
        // Swapping interface icons with SF Symbols
        // 3. Create instance of the image object
        let images = Images()
        //images.reactionLoveBig = UIImage(systemName: "bolt.heart.fill")!
        //images.reactionLoveBig = UIImage(systemName: "bolt.heart.fill")!
        images.reactionLoveBig = UIImage(named: "heart_broke")!
        images.reactionLoveSmall = UIImage(named: "heart_broke")!
        
        
        // Use the local variables after their declaration
        //let appearance = Appearance(colors: colors, images: images, fonts: fonts)
        let appearance = Appearance(colors: colors, images: images, fonts: fonts)
        
        /*let channelNamer: ChatChannelNamer = { channel, currentUserId in
         "This is our custom name: \(channel.name ?? "no name")"
         }*/
        
        streamChat = StreamChat(chatClient: chatClient, appearance: appearance)
        
        connectUser()
        
        return true
    }
    
    // The `connectUser` function we need to add.
    private func connectUser() {
        // This is a hardcoded token valid on Stream's tutorial environment.
        let token = try! Token(rawValue: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibHVrZV9za3l3YWxrZXIifQ.kFSLHRB5X62t0Zlc7nwczWUfsQMwfkpylC6jCUZ6Mc0")
        
        // Call `connectUser` on our SDK to get started.
        chatClient.connectUser(
            userInfo: .init(id: "luke_skywalker",
                            name: "Luke Skywalker",
                            imageURL: URL(string: "https://vignette.wikia.nocookie.net/starwars/images/2/20/LukeTLJ.jpg")!),
            token: token
        ) { error in
            if let error = error {
                // Some very basic error handling only logging the error.
                log.error("connecting the user failed \(error)")
                return
            }
        }
    }
}
