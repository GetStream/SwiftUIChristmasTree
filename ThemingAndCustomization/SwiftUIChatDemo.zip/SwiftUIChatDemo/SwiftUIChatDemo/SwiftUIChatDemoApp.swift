import SwiftUI
import StreamChat
import StreamChatSwiftUI

@main
struct SwiftUIChatDemoApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    let nordeaDarkRed = Color(#colorLiteral(red: 0.9058823529, green: 0.01568627451, blue: 0.01568627451, alpha: 1))
    var body: some Scene {
        WindowGroup {
            // Customizing the Channel List Header title
            ChatChannelListScreen(title: "Nordea Chat")
            // Overriding the color of titles: Channel list header and chat area, image labels in messages
                .foregroundColor(nordeaDarkRed)
        }
    }
}
